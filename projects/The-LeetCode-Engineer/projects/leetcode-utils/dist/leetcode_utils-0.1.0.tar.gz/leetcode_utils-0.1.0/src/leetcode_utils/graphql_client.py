from gql import gql, Client
from gql.transport.aiohttp import AIOHTTPTransport

# method: 'POST',
#       headers: {
#         'Content-Type': 'application/json',
#         Referer: 'https://leetcode.com',
#       },
#       body: JSON.stringify({
#         query: query,
#         variables: {
#           categorySlug: '',
#           skip,
#           limit,
#           filters: { tags,
#             difficulty
#            },
#         },
#       }),
#     });
transport = AIOHTTPTransport(url="https://leetcode.com/graphql")
client = Client(transport=transport, fetch_schema_from_transport=True)
query = gql(
    """
    query getProblems($categorySlug: String, $limit: Int, $skip: Int, $filters: QuestionListFilterInput) {
        problemsetQuestionList: questionList(
          categorySlug: $categorySlug
          limit: $limit
          skip: $skip
          filters: $filters
        ) {
          total: totalNum
          questions: data {
            acRate
            difficulty
            freqBar
            questionFrontendId
            isFavor
            isPaidOnly
            status
            title
            titleSlug
            topicTags {
                name
                id
                slug
            }
            hasSolution
            hasVideoSolution
          }
        }
      }`;
"""
)
# p = {
#   "categorySlug": ''
#   "skip": 
#   "limit": 
#   "filters": { 
#     tags,
#     difficulty
#   }
# }

# Execute the query on the transport
result = client.execute(query)
print(result)